import random
import time
import os


# Códigos de cores ANSI
class Cores:
    RESET = '\033[0m'
    BOLD = '\033[1m'

    # Cores do texto
    VERMELHO = '\033[91m'
    VERDE = '\033[92m'
    AMARELO = '\033[93m'
    AZUL = '\033[94m'
    MAGENTA = '\033[95m'
    CIANO = '\033[96m'
    BRANCO = '\033[97m'

    # Cores de fundo
    BG_VERMELHO = '\033[101m'
    BG_VERDE = '\033[102m'
    BG_AMARELO = '\033[103m'
    BG_AZUL = '\033[104m'
    BG_MAGENTA = '\033[105m'
    BG_CIANO = '\033[106m'


def limpar_tela():
    """Limpa a tela do terminal"""
    os.system('cls' if os.name == 'nt' else 'clear')


def efeito_digitacao(texto, velocidade=0.03):
    """Simula efeito de digitação"""
    for char in texto:
        print(char, end='', flush=True)
        time.sleep(velocidade)
    print()


def animacao_carregamento():
    """Animação de carregamento"""
    print(f"\n{Cores.CIANO}🤖 Computador pensando", end="")
    for i in range(3):
        for char in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏":
            print(f"\r{Cores.CIANO}🤖 Computador pensando {char}", end="", flush=True)
            time.sleep(0.1)
    print(f"\r{Cores.VERDE}🤖 Computador decidiu!     {Cores.RESET}")


def mostrar_logo():
    """Mostra logo do jogo com cores"""
    limpar_tela()
    logo = f"""
{Cores.BG_AZUL}{Cores.BRANCO}{Cores.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║    🪨  PEDRA    📄  PAPEL    ✂️   TESOURA                    ║
║                                                              ║
║           ⚡ BATALHA ÉPICA CONTRA O COMPUTADOR ⚡            ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Cores.RESET}
"""
    print(logo)
    time.sleep(1)


def obter_emoji_jogada(jogada):
    """Retorna emoji correspondente à jogada"""
    emojis = {
        "pedra": "🪨",
        "papel": "📄",
        "tesoura": "✂️"
    }
    return emojis.get(jogada, "❓")


def mostrar_versus(jogada_jogador, jogada_computador):
    """Mostra o versus com animação"""
    print(f"\n{Cores.BOLD}{Cores.AMARELO}{'=' * 60}{Cores.RESET}")
    print(f"{Cores.BOLD}{Cores.AZUL}                        ⚔️  VERSUS  ⚔️{Cores.RESET}")
    print(f"{Cores.BOLD}{Cores.AMARELO}{'=' * 60}{Cores.RESET}")

    time.sleep(0.5)

    emoji_jogador = obter_emoji_jogada(jogada_jogador)
    emoji_computador = obter_emoji_jogada(jogada_computador)

    print(f"""
{Cores.VERDE}{Cores.BOLD}           VOCÊ{Cores.RESET}                    {Cores.VERMELHO}{Cores.BOLD}COMPUTADOR{Cores.RESET}
{Cores.VERDE}{Cores.BOLD}        {emoji_jogador}  {jogada_jogador.upper()}{Cores.RESET}      VS      {Cores.VERMELHO}{Cores.BOLD}{jogada_computador.upper()}  {emoji_computador}{Cores.RESET}
""")


def mostrar_resultado(resultado, tipo_resultado):
    """Mostra resultado com efeitos especiais"""
    time.sleep(1)

    if tipo_resultado == "vitoria":
        print(f"\n{Cores.BG_VERDE}{Cores.BRANCO}{Cores.BOLD}")
        print("🎉 " * 20)
        print("🎉   🏆  VOCÊ VENCEU!  🏆   🎉" * 2)
        print("🎉 " * 20)
        print(f"{Cores.RESET}")

    elif tipo_resultado == "derrota":
        print(f"\n{Cores.BG_VERMELHO}{Cores.BRANCO}{Cores.BOLD}")
        print("💥 " * 20)
        print("💥   🤖  COMPUTADOR VENCEU!  🤖   💥")
        print("💥 " * 20)
        print(f"{Cores.RESET}")

    else:  # empate
        print(f"\n{Cores.BG_AMARELO}{Cores.BRANCO}{Cores.BOLD}")
        print("🤝 " * 20)
        print("🤝        EMPATE!        🤝" * 2)
        print("🤝 " * 20)
        print(f"{Cores.RESET}")


def mostrar_placar(vitorias_jogador, vitorias_computador, empates):
    """Mostra placar colorido"""
    total = vitorias_jogador + vitorias_computador + empates

    print(f"\n{Cores.BOLD}{Cores.CIANO}📊 PLACAR ATUAL{Cores.RESET}")
    print(f"{Cores.BOLD}{Cores.CIANO}{'─' * 30}{Cores.RESET}")

    # Percentuais
    if total > 0:
        perc_jogador = (vitorias_jogador / total) * 100
        perc_computador = (vitorias_computador / total) * 100
        perc_empate = (empates / total) * 100
    else:
        perc_jogador = perc_computador = perc_empate = 0

    print(f"{Cores.VERDE}🏆 Você:        {vitorias_jogador:2d} vitórias ({perc_jogador:5.1f}%){Cores.RESET}")
    print(f"{Cores.VERMELHO}🤖 Computador:  {vitorias_computador:2d} vitórias ({perc_computador:5.1f}%){Cores.RESET}")
    print(f"{Cores.AMARELO}🤝 Empates:     {empates:2d} jogos    ({perc_empate:5.1f}%){Cores.RESET}")
    print(f"{Cores.BOLD}{Cores.CIANO}{'─' * 30}{Cores.RESET}")
    print(f"{Cores.MAGENTA}📈 Total de jogos: {total}{Cores.RESET}\n")


def jogo_pedra_papel_tesoura():
    """
    Jogo de Pedra, Papel e Tesoura contra o computador - Versão Deluxe
    """
    mostrar_logo()

    # Lista de opções disponíveis
    opcoes = ["pedra", "papel", "tesoura"]

    # Contadores de vitórias
    vitorias_jogador = 0
    vitorias_computador = 0
    empates = 0

    efeito_digitacao(f"{Cores.BOLD}{Cores.VERDE}🎮 Bem-vindo ao jogo mais épico de todos os tempos!{Cores.RESET}")
    efeito_digitacao(f"{Cores.AMARELO}💡 Dica: Digite 'sair' para encerrar a qualquer momento{Cores.RESET}")

    input(f"\n{Cores.CIANO}🚀 Pressione ENTER para começar a batalha...{Cores.RESET}")

    while True:
        limpar_tela()
        mostrar_placar(vitorias_jogador, vitorias_computador, empates)

        # Input do jogador com estilo
        print(f"{Cores.BOLD}{Cores.AZUL}🎯 Faça sua escolha:{Cores.RESET}")
        print(f"{Cores.VERDE}🪨  pedra    📄  papel    ✂️   tesoura{Cores.RESET}")
        jogada_jogador = input(f"\n{Cores.AMARELO}➤ Sua jogada: {Cores.RESET}").lower().strip()

        # Verificar se o jogador quer sair
        if jogada_jogador == 'sair':
            print(f"\n{Cores.MAGENTA}👋 Obrigado por jogar! Até a próxima batalha!{Cores.RESET}")
            time.sleep(2)
            break

        # Verificar se a jogada é válida
        if jogada_jogador not in opcoes:
            print(f"\n{Cores.VERMELHO}❌ Opção inválida! Escolha: pedra, papel ou tesoura{Cores.RESET}")
            time.sleep(2)
            continue

        # Computador faz sua escolha aleatória com animação
        animacao_carregamento()
        jogada_computador = random.choice(opcoes)

        # Mostrar versus
        mostrar_versus(jogada_jogador, jogada_computador)

        # Determinar o vencedor
        if jogada_jogador == jogada_computador:
            mostrar_resultado("Empate!", "empate")
            empates += 1
        elif (jogada_jogador == "pedra" and jogada_computador == "tesoura") or \
                (jogada_jogador == "papel" and jogada_computador == "pedra") or \
                (jogada_jogador == "tesoura" and jogada_computador == "papel"):
            mostrar_resultado("Vitória!", "vitoria")
            vitorias_jogador += 1
        else:
            mostrar_resultado("Derrota!", "derrota")
            vitorias_computador += 1

        input(f"\n{Cores.CIANO}⏳ Pressione ENTER para continuar...{Cores.RESET}")

    # Mostrar placar final
    limpar_tela()
    print(f"\n{Cores.BG_MAGENTA}{Cores.BRANCO}{Cores.BOLD}")
    print("🏁 " * 15)
    print("🏁      RESULTADO FINAL      🏁")
    print("🏁 " * 15)
    print(f"{Cores.RESET}")

    mostrar_placar(vitorias_jogador, vitorias_computador, empates)

    total_jogos = vitorias_jogador + vitorias_computador + empates
    if total_jogos > 0:
        if vitorias_jogador > vitorias_computador:
            print(f"\n{Cores.BG_VERDE}{Cores.BRANCO}{Cores.BOLD}")
            print("🎊 🏆 PARABÉNS! VOCÊ É O CAMPEÃO SUPREMO! 🏆 🎊")
            print(f"{Cores.RESET}")
        elif vitorias_computador > vitorias_jogador:
            print(f"\n{Cores.BG_VERMELHO}{Cores.BRANCO}{Cores.BOLD}")
            print("🤖 💪 O COMPUTADOR DOMINOU A PARTIDA! 💪 🤖")
            print(f"{Cores.RESET}")
        else:
            print(f"\n{Cores.BG_AMARELO}{Cores.BRANCO}{Cores.BOLD}")
            print("⚖️  🤝 EMPATE ÉPICO! VOCÊS SÃO IGUAIS! 🤝 ⚖️")
            print(f"{Cores.RESET}")


def jogar_uma_partida():
    """
    Função para jogar apenas uma partida - Versão Deluxe
    """
    mostrar_logo()
    opcoes = ["pedra", "papel", "tesoura"]

    efeito_digitacao(f"{Cores.BOLD}{Cores.AMARELO}⚡ MODO PARTIDA RÁPIDA ⚡{Cores.RESET}")

    # Input do jogador
    print(f"\n{Cores.BOLD}{Cores.AZUL}🎯 Faça sua escolha para a batalha:{Cores.RESET}")
    print(f"{Cores.VERDE}🪨  pedra    📄  papel    ✂️   tesoura{Cores.RESET}")
    jogada_jogador = input(f"\n{Cores.AMARELO}➤ Sua jogada: {Cores.RESET}").lower().strip()

    if jogada_jogador not in opcoes:
        print(f"\n{Cores.VERMELHO}❌ Opção inválida! Tente novamente.{Cores.RESET}")
        time.sleep(2)
        return

    # Computador escolhe aleatoriamente
    animacao_carregamento()
    jogada_computador = random.choice(opcoes)

    # Mostrar versus
    mostrar_versus(jogada_jogador, jogada_computador)

    # Determinar vencedor
    if jogada_jogador == jogada_computador:
        mostrar_resultado("Empate!", "empate")
    elif (jogada_jogador == "pedra" and jogada_computador == "tesoura") or \
            (jogada_jogador == "papel" and jogada_computador == "pedra") or \
            (jogada_jogador == "tesoura" and jogada_computador == "papel"):
        mostrar_resultado("Vitória!", "vitoria")
    else:
        mostrar_resultado("Derrota!", "derrota")

    input(f"\n{Cores.MAGENTA}✨ Pressione ENTER para finalizar...{Cores.RESET}")


# Função principal para escolher o modo de jogo
if __name__ == "__main__":
    try:
        mostrar_logo()

        efeito_digitacao(
            f"{Cores.BOLD}{Cores.VERDE}🎮 Bem-vindo ao Jogo Mais Épico de Pedra, Papel e Tesoura!{Cores.RESET}")

        print(f"\n{Cores.BOLD}{Cores.CIANO}🎯 Escolha seu modo de batalha:{Cores.RESET}")
        print(f"{Cores.AMARELO}1️⃣  - Jogo completo (várias partidas épicas){Cores.RESET}")
        print(f"{Cores.VERDE}2️⃣  - Uma partida rápida (ação instantânea){Cores.RESET}")

        modo = input(f"\n{Cores.MAGENTA}➤ Digite 1 ou 2: {Cores.RESET}").strip()

        if modo == "1":
            jogo_pedra_papel_tesoura()
        elif modo == "2":
            jogar_uma_partida()
        else:
            print(f"\n{Cores.VERMELHO}❌ Opção inválida! Execute o programa novamente.{Cores.RESET}")
            time.sleep(2)

    except KeyboardInterrupt:
        print(f"\n\n{Cores.AMARELO}👋 Jogo interrompido. Até mais!{Cores.RESET}")
    except Exception as e:
        print(f"\n{Cores.VERMELHO}❌ Erro inesperado: {e}{Cores.RESET}")
    finally:
        print(f"\n{Cores.CIANO}🎮 Obrigado por jogar! Game Over!{Cores.RESET}")