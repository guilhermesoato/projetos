import requests
from fuzzywuzzy import process
from colorama import Fore, Back, Style, init

init(autoreset=True)

filmes_possiveis = ["The Dark Knight", "The Matrix", "Inception", "Batman Begins", "Interstellar", "The Prestige", "Dunkirk"]

def encontrar_filme_correspondente(nome_filme):
    filme_correspondente = process.extractOne(nome_filme, filmes_possiveis)
    return filme_correspondente

def buscar_filme(nome_filme):
    api_key = 'ad305519'
    url = f'http://www.omdbapi.com/?s={nome_filme}&apikey={api_key}'

    resposta = requests.get(url)

    if resposta.status_code == 200:
        dados = resposta.json()
        if dados['Response'] == 'True':
            for filme in dados['Search']:
                print(f"\n{Fore.GREEN}🎬 Título: {Fore.CYAN}{filme['Title']}{Style.RESET_ALL}")
                print(f"{Fore.YELLOW}📅 Ano: {filme['Year']}{Style.RESET_ALL}")
                print(f"{Fore.RED}⭐ IMDb ID: {filme['imdbID']}{Style.RESET_ALL}")

                detalhes_url = f"http://www.omdbapi.com/?i={filme['imdbID']}&apikey={api_key}"
                detalhes_resposta = requests.get(detalhes_url)
                
                if detalhes_resposta.status_code == 200:
                    detalhes = detalhes_resposta.json()
                    if detalhes['Response'] == 'True':
                        print(f"{Fore.YELLOW}📜 Sinopse: {Fore.CYAN}{detalhes['Plot']}{Style.RESET_ALL}")
                    else:
                        print(f"{Fore.RED}❌ Não foi possível obter mais detalhes sobre o filme.\n")
                else:
                    print(f"{Fore.RED}❌ Erro ao buscar detalhes do filme.\n")
        else:
            print(f"{Fore.YELLOW}⚠️ Nenhum filme encontrado com o nome '{nome_filme}'. Tentando correção de digitação...\n")
            filme_correspondente = encontrar_filme_correspondente(nome_filme)
            if filme_correspondente:
                print(f"{Fore.CYAN}💡 Você quis dizer '{filme_correspondente[0]}'? Com a pontuação de {filme_correspondente[1]}%.")
                buscar_filme(filme_correspondente[0])
            else:
                print(f"{Fore.RED}❌ Nenhuma sugestão encontrada para esse nome.\n")
    else:
        print(f"{Fore.RED}❌ Erro na requisição à API OMDb.\n")

print(f"{Fore.GREEN}{Back.BLACK}🎬 Bem-vindo ao Oráculo dos Filmes! 🎥{Style.RESET_ALL}")
print(f"{Fore.YELLOW}Digite o nome de um filme ou 'sair' para encerrar.\n")
print(f"{Fore.RED}Esse Chatbot foi desenvolvido por Guilherme Soato!\n")
while True:
    nome = input(f"{Fore.CYAN}Digite o nome do filme: {Style.RESET_ALL}")

    if nome.lower() == 'sair':
        print(f"\n{Fore.RED}{Back.YELLOW}👋 Programa encerrado. Até logo!{Style.RESET_ALL}")
        break

    buscar_filme(nome)
